package game;

public enum GameState {
	MENU,
	GAME,
	EDITOR;
}
