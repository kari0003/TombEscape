package game;

public enum TileType {
	WALKABLE,
	UNWALKABLE,
	ICE;
}
