package game.entities;

import main.TombEscapeGame;

import com.badlogic.gdx.math.Vector2;

public class StartPoint extends Entity {

	public StartPoint(Vector2 pos) {
		super(pos);
		
	}

	@Override
	protected void update() {
		
	}

}
